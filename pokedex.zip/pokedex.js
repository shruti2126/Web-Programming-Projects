    /*
        Name: Shruti Sharma
        Class: CSE 154 section AG
        Date: 5/17/2018
        
        This is the javascript file for the pokedex game. It adds all sprites 
        in the pokedex view,populates the card for each pokemon when they are 
        clicked on or when game starts.
        It runs the game and declares a winner and loser. It also allows you 
        chose different pokemons to fight against random pokemons and use various 
        moves to play the game.
    */
    
    /*global fetch*/
    "use strict";
    (function() {

        /**
         *  Shortcut to get the document element by id
         *  @param {string} the id of html element selected
         *  @return {DOM} the DOM element with that particular ID
         */
        function $(id) {
            return document.getElementById(id);
        }

        /**
         * @param {string} CSS selector
         * @return {DOM} Array of html elements selected
         */
        function $$(selector) {
            return document.querySelector(selector);
        }

        /**
         * @param {string} CSS selector
         * @return {DOM} the html element selected
         */
        function qsa(selector) {
            return document.querySelectorAll(selector);
        }

        const MOVES_BUTTONS = 4; //the maximum number of buttons available for moves
        let myPokemon; //the pokemon I choose and play moves through
        let guid; //game state id
        let pid; //player id
        let myDefaultHP; //the default HP of my pokemon
        let found = []; //contains all pokemon that can be selected
        let gameURL = "https://webster.cs.washington.edu/pokedex/game.php?"; 
        //URL to fetch game data 
                                                                             
        /**
         * Sets up all event handlers like the start button, 
         * the moves buttons, the endgame button,what is visible when page loads
         * and what happens when a sprite is clicked
         * Makes an ajax call to fetch data of all sprites in the pokedex view.
        */
        window.onload = function() {
            callAjax();
            $("start-btn").onclick = changeGameView;
            let movesButtons = document.querySelectorAll(".moves > button");
            for (let i = 0; i < movesButtons.length; i++) {
                movesButtons[i].onclick = gameState;
            }
            $("endgame").onclick = endGame;
            $("flee-btn").onclick = loseGame;
        }

        /**
         * @param {object} pokemon that was selected
         * Fetches the pokemon data
         * Calls on function that populates pokemon's card
        */
        function fetchPokemonData(pokemon) {
            let url = "https://webster.cs.washington.edu/pokedex/pokedex.php?pokemon=" + pokemon.id;
            myPokemon = pokemon;
            fetch(url, {
                    mode: "cors"
                })
                .then(checkStatus)
                .then(JSON.parse)
                .then(populateCard)
                .catch(function(error) {
                    console.log(error);
                });
        }

        /**
         * @param {JSON} data returned from ajax call
         * Populates both players' cards
         * Shows the "choose this pokemon" button
        */
        function populateCard(data) {
            populateCards(data, "#my-card");
            $("start-btn").classList.remove("hidden");
        }

        /**
         * @param {JSON} data returned from ajax call
         * @param {string} CSS selector
         * Places information from data into cards for e.g the images, 
         * the description etc.
         * Hides extra buttons if pokemon has less than 4 moves.
        */
        function populateCards(data, card) {
            let iconUrl = "https://webster.cs.washington.edu/pokedex/";
            let moves = data.moves;
            if (card === "#their-card") {
                moves = data.p2.moves;
            }
            insertInfo(card, data);
            let spans = qsa(card + " .moves > button > .move");
            let dps = qsa(card + " .moves > button > .dp");
            let img = qsa(card + " .moves > button > img");
            pokemonMoves(card, spans, img, dps, iconUrl, moves);
        }

        /**
         * @param {string} pokemon's card, {JSON} data returned from
         * ajax call to fetch pokemon data
         * Inserts the info from data fetched into the card.
        */
        function insertInfo(card, data) {
            let iconUrl = "https://webster.cs.washington.edu/pokedex/";
            let name = data.name;
            let images = data.images;
            let info = data.info;
            let hp = data.hp;
            myDefaultHP = hp;
            if (card === "#their-card") {
                images = data.p2.images;
                info = data.p2.info;
                hp = data.p2.hp;
                name = data.p2.name;
            }
            myDefaultHP = hp;
            $$(card + " .name").innerHTML = name;
            $$(card + " .type").src = iconUrl + images.typeIcon;
            $$(card + " .pokepic").src = "https://webster.cs.washington.edu/pokedex/" +
                images.photo;
            $$(card + " .weakness").src = iconUrl + images.weaknessIcon;
            $$(card + " .hp").innerHTML = hp + "HP";
            $$(card + " .info").innerHTML = info.description;
        }

        /**
         * @param {DOM} the html span element, {DOM} the image of pokemon, 
         * {string} url for retrieving icon images, {string} and moves of pokemon.
         * Hiddes extra buttons if moves of pokemon are less than four.
         * Places the dp into the card.
        */
        function pokemonMoves(card, spans, img, dps, iconUrl, moves) {
            let buttons = qsa(card + " .moves > button");
            showAllMovesButtons(card, buttons);
            let numberOfMoves = moves.length;
            for (let i = 0; i < numberOfMoves; i++) {
                spans[i].innerHTML = moves[i].name;
                img[i].src = iconUrl + "icons/" + moves[i].type + ".jpg";
                let dp = moves[i].dp;
                if (dp) {
                    dps[i].innerHTML = dp + "DP";
                } else {
                    dps[i].innerHTML = " ";
                }
            }
            hideMovesButtons(numberOfMoves, buttons);
        }
        
        /**
         * @param {integer} the number of moves pokemon has, 
         * {DOM} the buttons for moves on the card.
         * Hides buttons not filled in with moves.
        */ 
        function hideMovesButtons(numberOfMoves, buttons) {
          if (numberOfMoves < MOVES_BUTTONS) {
            for (let i = MOVES_BUTTONS - 1; i > numberOfMoves - 1; i--) {
                buttons[i].classList.add("hidden");
             }
           }
        }
        
        /**
         * @param {string} pokemon's card, {DOM} the buttons for moves on the card.
         * Shows all buttons on card.
         */ 
        function showAllMovesButtons(card, buttons) {
          for (let i = 0; i < MOVES_BUTTONS; i++) {
              buttons[i].classList.remove("hidden");
            }
        }

        /**
         * Changes the view of the screen when start button is pressed.
         * Toggles display of the pokedex view, opponents card, start button,
         * flee button, results container and the buffs for the cards.
         * Displays hp informtion for both cards, resets the health bars,
         * enables, flee button, changes the title to pokemon battle mode and 
         * enables of moves buttons on the card.
         * Also calls function to initialize the game.
        */
        function changeGameView() {
            let displays = [];
            displays.push($$("#my-card .buffs"), $("pokedex-view"), $("their-card"),
                $("results-container"), $("start-btn"), $("flee-btn"));
            toggleHidden(displays);
            $("p1-turn-results").innerHTML = "";
            $("p2-turn-results").innerHTML = "";
            displayHpInfo();
            resetHealthBars();
            $("flee-btn").disabled = false;
            $("title").innerHTML = "Pokemon Battle Mode!";
            let buttons = qsa("button");
            for (let i = 0; i < MOVES_BUTTONS; i++) {
                buttons[i].disabled = false;
            }
            initializeGame();
        }

        /**
         * Makes POST request to the gameURL with pokemon name to start game 
         * and parses the data returned.
        */
        function initializeGame() {
            let data = new FormData();
            data.append("startgame", "true");
            data.append("mypokemon", myPokemon.id);

            fetch(gameURL, {
                    method: "POST",
                    body: data,
                    mors: "code"
                })
                .then(checkStatus)
                .then(JSON.parse)
                .then(startGame)
                .catch(function(error) {
                    console.log(error);
                });
        }
        
        /**
         * Saves game state ID and player ID for reference.
         * Populates the opponent's card.
        */ 
        function startGame(responseText) {
            guid = responseText.guid;
            pid = responseText.pid;
            populateCards(responseText, "#their-card");
        }
        
        /**
         * Sets the game's state after a move is played by making POST
         * request to gameURL and parsing the data.
        */ 
        function gameState() {
            $("loading").classList.toggle("hidden");
            let move = this.querySelector(".move").innerText;
            let data = new FormData();
            data.append("guid", guid);
            data.append("pid", pid);
            data.append("movename", move);

            fetch(gameURL, {
                    method: "POST",
                    body: data,
                    mors: "code"
                })
                .then(checkStatus)
                .then(JSON.parse)
                .then(updateState)
                .catch(function(error) {
                    console.log(error);
                });
        }
        
        /**
         * Displays hp information for both players.
        */ 
        function displayHpInfo() {
           let hpInfo = qsa(".hp-info");
           for (let i = 0; i < hpInfo.length; i++) {
                hpInfo[i].classList.remove("hidden");
            }
        }
        
        /**
         * Reset both health bars to be green and of full width.
        */ 
        function resetHealthBars() {
            let healthBars = qsa(".health-bar");
            for (let i = 0; i < healthBars.length; i++) {
                healthBars[i].classList.remove("low-health");
                healthBars[i].style.width = 100 + "%";
            }
        }
        
        /**
         * Updates the state of the game after each game.
         * @param {JSON} response returned from POST request
         * Shows results, shows hp infos, displays buffs and debuffs 
         * for both cards.
        */ 
        function updateState(responseText) {
            $("loading").classList.toggle("hidden");
            let player1 = {
                move: responseText.results["p1-move"],
                result: responseText.results["p1-result"],
                healthBar: $$("#my-card .health-bar"),
                currentHp: responseText.p1["current-hp"]
            };
            let player2 = {
                move: responseText.results["p2-move"],
                result: responseText.results["p2-result"],
                healthBar: $$("#their-card .health-bar"),
                currentHp: responseText.p2["current-hp"]
            };
            let players = [player1, player2];
            let hps = [responseText.p1.hp, responseText.p2.hp];
            showResults(player1, player2);
            displayHpInfo();
            setHpInfo(players, player1, player2, hps);
            buffDebuff(responseText);
            if (player1.currentHp === 0 || player2.currentHp === 0) {
                $("endgame").classList.remove("hidden");
                resultNull(responseText, player1, player2);
            }
        }
       
        /**
         *@param {array} both players, {array} containing information 
         * about player1, {array} containing information about player2, 
         * {array} hps.
         * Changes the appearance of the health bars after each move
         * Changes the hp information on each card after the moves.
        */ 
        function setHpInfo(players, player1, player2, hps) {
            for (let i = 0; i < players.length; i++) {
                players[i].healthBar.style.width = 
                    (players[i].currentHp / hps[i]) * 100 + "%";
                let width = parseInt(players[i].healthBar.style.width);
                if (width <= 20) {
                    players[i].healthBar.classList.add("low-health");
                }
                if (i === 0) {
                    $$("#my-card .hp").innerHTML = player1.currentHp + "HP";
                } else {
                    $$("#their-card .hp").innerHTML = player2.currentHp + "HP";
                }
            }
        }
        
        /**
         * @param {array} containing information about player1, 
         * {array} containing information about player 2.
         * Shows the results of the game after each move is played.
        */ 
        function showResults(player1, player2) {
            $("p1-turn-results").classList.remove("hidden");
            $("p2-turn-results").classList.remove("hidden");
            $("p1-turn-results").innerHTML = "Player 1 played " + player1.move +
                " and " + player1.result + "!";
            $("p2-turn-results").innerHTML = "Player 2 played " + player2.move +
                " and " + player2.result + "!";
        }
        
        /**
         * @param {JSON} data return from POST request, 
         * {array} player1, {array} player2.
         * Displays who won or lost based on data returned from call.
        */
        function resultNull(responseText, player1, player2) {
            if (player1.result === null) {
                $("p1-turn-results").classList.add("hidden");
                $("title").innerHTML = "You lost!";
            } else if (player2.result === null) {
                $("p2-turn-results").classList.add("hidden");
                youWon(responseText);
            }
            win(responseText, player1, player2);
        }
        
        /**
         * @param {JSON} data return from POST request
         * Displays message "You won!" when a pokemon wins.
         * Adds the opponent who lost into the collection of found pokemons.
        */ 
        function youWon(responseText) {
           $("title").innerHTML = "You won!";
                let newPokemon = responseText.p2.name;
                foundPokemon(newPokemon);
            }
    
        /**
         * @param {JSON} data return from POST request, 
         * {array} player1, {array} player2
         * Displays message you lost if current HP is 0 for my pokemon
         * and you won if player 2's HP is 0.
        */ 
        function win(responseText, player1, player2) {
            if (player1.currentHp === 0) {
                $("title").innerHTML = "You lost!";
            } else if (player2.currentHp === 0) {
                youWon(responseText);
            }
        }
        
        /**
         * @param {object} the new pokemon that lost the game
         * Pushes the pokemon into the found array
         * Adds an onclick function to make it clickable.
         * Fetches the data for the pokemon
        */ 
        function foundPokemon(newPokemon) {
            if (!(found.includes(newPokemon))) {
                found.push(newPokemon);
                $(newPokemon).classList.add("found");
                $(newPokemon).onclick = function() {
                    fetchPokemonData($(newPokemon));
                }
            }
        }
        
        /**
         * Hides elements that were shown earlier and displays 
         * those that were hidden like start button, flee button.
         * Resets the HP of my pokemon to DefaultHP.
         * Removes the buffs from the cards.
        */ 
        function endGame() {
            let toHide = [$("endgame"), $("results-container"), $("their-card")];
            for (let i = 0; i < toHide.length; i++) {
                toHide[i].classList.add("hidden");
            }
            fetchPokemonData(myPokemon);
            let toggle = [$("start-btn"),  $("flee-btn"), $("pokedex-view")];
            toggleHidden(toggle);
            $$("#my-card .hp").innerHTML = myDefaultHP;
            $("title").innerHTML = "Your Pokedex";
            let hpInfo = qsa(".hp-info");
            for (let i = 0; i < hpInfo.length; i++) {
                hpInfo[i].classList.remove("low-health");
                hpInfo[i].classList.add("hidden");
            }
            removeBuffs();
        }
        
        /**
         * @param {array} array of DOM elements that need to be either
         * hidden or displayed.
         * Hides them if they were not and displayes them if they were hidden.
        */ 
        function toggleHidden(array){
            for(let i = 0; i < array.length; i++) {
                array[i].classList.toggle("hidden");
            }
        }
        
        /**
         * Removes the buffs from both cards.
        */ 
        function removeBuffs() {
            let buffs = qsa(".buffs");
            for (let i = 0; i < buffs.length; i++) {
                buffs[i].innerHTML = "";
            }
        }
        
        /**
         * @param {JSON} data returned from POST request.
         * Adds the buffs and debuffs to the cards after each move.
        */ 
        function buffDebuff(responseText) {
            removeBuffs();
            let allBuffs = [responseText.p1.buffs, responseText.p2.buffs];
            let allDebuffs = [responseText.p1.debuffs, responseText.p2.debuffs];
            populateBuffs(allBuffs);
            populateDebuffs(allDebuffs);
        }

        /**
         * @param {array} array containing all buffs information for 
         * pokemon cards
         * Adds the buffs to each card depending on the data in the array.
         */ 
        function populateBuffs(allBuffs) {
            for (let i = 0; i < allBuffs.length; i++) {
                if (allBuffs[i].length != 0) {
                    for (let j = 0; j < allBuffs[i].length; j++) {
                        let div = document.createElement("div");
                        div.classList.add("buff");
                        let theBuffs = allBuffs[i];
                        for (let k = 0; k < theBuffs.length; k++) {
                            div.classList.add(theBuffs[k]);
                        }
                        if (i == 0) {
                            $$("#my-card .buffs").appendChild(div);
                        } else {
                            $$("#their-card .buffs").appendChild(div);
                        }

                    }
                }
            }

        }
        
        /**
         * @param {array} array containing all debuffs information for 
         * pokemon cards.
         * Adds the debuffs to each card depending on the data in the array.
         */ 
        function populateDebuffs(allDebuffs) {
            for (let i = 0; i < allDebuffs.length; i++) {
                if (allDebuffs[i].length != 0) {
                    for (let j = 0; j < allDebuffs[i].length; j++) {
                        let div = document.createElement("div");
                        div.classList.add("debuff");
                        let theDebuffs = allDebuffs[i];
                        for (let k = 0; k < theDebuffs.length; k++) {
                            div.classList.add(theDebuffs[k]);
                        }
                        if (i == 0) {
                            $$("#my-card .buffs").appendChild(div);
                        } else {
                            $$("#their-card .buffs").appendChild(div)
                        }

                    }
                }
            }
        }
        
        /**
         * Makes post request to gameURL with movename flee and parses data.
         */ 
        function loseGame() {
            let url = "https://webster.cs.washington.edu/pokedex/game.php?";
            let data = new FormData();
            data.append("guid", guid);
            data.append("pid", pid);
            data.append("movename", "flee");
            fetch(url, {
                    method: "POST",
                    body: data,
                    mors: "code"
                })
                .then(checkStatus)
                .then(JSON.parse)
                .then(flee)
                .catch(function(error) {
                    console.log(error);
                });
        }
        
        /**
         * @param {JSON} data returned from POST request.
         * Changes title to "you lost" when flee button is clicked, 
         * hides player 2's results, Displays the "Back to pokedec" button 
         * and displayes the results of player 1.
         */ 
        function flee(responseText) {
            $("title").innerHTML = "You lost!";
            $("p2-turn-results").classList.add("hidden");
            $("endgame").classList.remove("hidden");
            $("p1-turn-results").innerHTML = "Player 1 played " + 
                responseText.results["p1-move"] +
                    " and " + responseText.results["p1-result"] + "!";
        }


        /**
         * Function to check the status of an Ajax call, boiler plate code to 
         * include, based on:
         * https://developers.google.com/web/updates/2015/03/introduction-to-fetch
         * @param the response text from the url call
         * @return did we succeed or not, so we know whether or not to continue 
         * with the handling of this promise
         */
        function checkStatus(response) {
            if (response.status >= 200 && response.status < 300) {
                return response.text();
            } else {
                return Promise.reject(new Error(response.status +
                    ": " + response.statusText));
            }
        }

        /**
         * Fetches all sprites (pokemon)
         * appends all 151 sprites into box on right side of the screen
         * Makes the three sprites (Bulbasur, charmander and Squirtle) 
         * show up in the box.
         * Fetches pokemon data if when sprite is clicked.
         */
        function callAjax() {
            let url = "https://webster.cs.washington.edu/pokedex/pokedex.php?pokedex=all";
            fetch(url, {
                    mode: "cors"
                })
                .then(checkStatus)
                .then(success)
                .catch(function(error) {
                    console.log(error);
                });
        }

        function success(responseText) {
            let view = $("pokedex-view");
            responseText = responseText.split("\n");
            for (let i = 0; i < responseText.length; i++) {
                let string = responseText[i].split(":");
                let name = string[0];
                let path = string[1];
                let image = document.createElement("img");
                image.src = "https://webster.cs.washington.edu/pokedex/sprites/" + path;
                image.id = name;
                image.classList.add("sprite");
                found.push("Bulbasaur", "Charmander", "Squirtle");
                for (let i = 0; i < found.length; i++) {
                    if (name === found[i]) {
                        image.classList.add("found");
                    }
                }
                spriteOnclick();
                view.appendChild(image);
            }
        }
        
        /**
         * Fetches the data for the pokemon/sprite that is clicked from the 
         * pokedex view.
         */
        function spriteOnclick(){
         let sprites = document.querySelectorAll("#pokedex-view img");
         for (let i = 0; i < sprites.length; i++) {
            let sprite = sprites[i];
            if (sprite.classList.contains("found")) {
                sprite.onclick = function() {
                    fetchPokemonData(this);
                }
            }
        }
    }
    })();